#!/usr/bin/perl -w

use SequencesViewer;

my $seqViewer = new SequencesViewer;
$seqViewer->init();
$seqViewer->run();

