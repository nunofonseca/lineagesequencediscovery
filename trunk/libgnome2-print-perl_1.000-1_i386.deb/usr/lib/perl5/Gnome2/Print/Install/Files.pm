package Gnome2::Print::Install::Files;

$self = {
          'inc' => '-D_REENTRANT -I/usr/include/libgnomeprintui-2.2 -I/usr/include/libgnomeprint-2.2 -I/usr/include/libgnomecanvas-2.0 -I/usr/include/libart-2.0 -I/usr/include/glib-2.0 -I/usr/lib/glib-2.0/include -I/usr/include/libxml2 -I/usr/include/pango-1.0 -I/usr/include/gail-1.0 -I/usr/include/gtk-2.0 -I/usr/include/freetype2 -I/usr/include/atk-1.0 -I/usr/lib/gtk-2.0/include -I/usr/include/cairo -I/usr/include/pixman-1 -I/usr/include/directfb -I/usr/include/libpng12   -I. -I./build ',
          'typemaps' => [
                          'gnomeprintperl.typemap',
                          'gnomeprint.typemap'
                        ],
          'deps' => [
                      'Glib',
                      'Gtk2',
                      'Cairo'
                    ],
          'libs' => '-lgnomeprintui-2-2 -lgnomeprint-2-2 -lz -lgnomecanvas-2 -lxml2 -lart_lgpl_2 -lgtk-x11-2.0 -lgdk-x11-2.0 -latk-1.0 -lpangoft2-1.0 -lgdk_pixbuf-2.0 -lm -lpangocairo-1.0 -lgio-2.0 -lcairo -lpango-1.0 -lfreetype -lfontconfig -lgobject-2.0 -lgmodule-2.0 -lglib-2.0  '
        };


# this is for backwards compatiblity
@deps = @{ $self->{deps} };
@typemaps = @{ $self->{typemaps} };
$libs = $self->{libs};
$inc = $self->{inc};

	$CORE = undef;
	foreach (@INC) {
		if ( -f $_ . "/Gnome2/Print/Install/Files.pm") {
			$CORE = $_ . "/Gnome2/Print/Install/";
			last;
		}
	}

1;
