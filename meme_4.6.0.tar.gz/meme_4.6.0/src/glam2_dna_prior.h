#ifndef GLAM2_DNA_PRIOR_H
#define GLAM2_DNA_PRIOR_H

#include "glam2_dirichlet.h"

void dmix_dna(dirichlet_mix *m);

#endif
