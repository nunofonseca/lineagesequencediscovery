#ifndef GLAM2_SCAN_INIT_H
#define GLAM2_SCAN_INIT_H

#include "glam2_scan.h"

void init(data *d);

#endif
