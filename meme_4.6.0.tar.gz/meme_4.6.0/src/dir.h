#define MEME_DIR "/net/noble/vol1/home/cegrant/meme"
#define ETC_DIR "/net/noble/vol1/home/cegrant/meme/etc" 
#define BIN_DIR "/net/noble/vol1/home/cegrant/meme/bin" 
