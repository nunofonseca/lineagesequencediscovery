/*
 * Copyright (c) 2003-2005 by Emmanuele Bassi (see the file AUTHORS)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the 
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330, 
 * Boston, MA  02111-1307  USA.
 */

#ifndef _GTK_SOURCE_VIEW_PERL_H_
#define _GTK_SOURCE_VIEW_PERL_H_

#include "gperl.h"
#include "gtk2perl.h"
#include "gnomeprintperl.h"

/* basic include files */
#include <gtksourceview/gtksourcebuffer.h>
#include <gtksourceview/gtksourceiter.h>
#include <gtksourceview/gtksourcelanguage.h>
#include <gtksourceview/gtksourcelanguagesmanager.h>
#include <gtksourceview/gtksourcemarker.h>
#include <gtksourceview/gtksourceprintjob.h>
#include <gtksourceview/gtksourcestylescheme.h>
#include <gtksourceview/gtksourcetag.h>
#include <gtksourceview/gtksourcetagstyle.h>
#include <gtksourceview/gtksourcetagtable.h>
#include <gtksourceview/gtksourceview-typebuiltins.h>
#include <gtksourceview/gtksourceview.h>

#include "gtksourceviewperl-autogen.h"
#include "gtksourceviewperl-version.h"

#endif /* _GTK_SOURCE_VIEW_PERL_H_ */
