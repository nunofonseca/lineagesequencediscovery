#!/bin/sh
export PATH=$PATH:/opt/lineagesequencediscovery/sigdis/
